<?php
  include 'header.php';
?>

<main>
  <section class="form-banner">
  <div class="addevent-form">
    <h1>Add Event</h1>
    <?php
    if(isset($_GET['event'])){
      if($_GET['event'] == "emptyfields") {
        echo '<p class="error">Fill all fields</p>';
      }
      elseif ($_GET['event'] == "sizelarge") {
        echo '<p class="error">Picture size too large</p>';
      }
      elseif ($_GET['event'] == "uploaderror") {
        echo '<p class="error">Invalid Email</p>';
      }
      elseif ($_GET['event'] == "wrongfileext") {
        echo '<p class="error">Invalid Username</p>';
      }
    }

    ?>
    <form action="includes/addevent.inc.php" method="post" enctype='multipart/form-data'>
      <div class="txtb">
        <label>Event name :</label>
        <input type="text" name="eventname" value="" placeholder="Enter Event Name">
      </div>
      <div class="txtb">
        <label>location:</label><select name="location">
          <option>Karachi</option>
          <option>Lahore</option>
          <option>Peshawar</option>
          <option>Quetta</option>
        </select>
      </div>
      <div class="txtb">
        <label>Catogary:</label><select name="catogary">
          <option>Carnival</option>
          <option>Concert</option>
          <option>Qawali</option>
        </select>
      </div>
      <div class="txtb">
        <label>Phone Number :</label>
        <input type="text" name="phonenumber" value="" placeholder="Enter Your Phone Number">
      </div>
      <div class="txtb">
        <label>Cover Image :</label>
        <input type="file" name="file" placeholder="Upload Image">
      </div>
      <label class="dates">EVENT DATE: </label><input type="date" name="eventdate">
      <div class="txtb">
        <label>Event Details :</label>
        <textarea name="eventdetails"></textarea>
      </div>
      <button class="btn" type="submit" name="submit-addevent">SUBMIT</button>
    </form>
  </div>
  </section>


</main>
<?php
  include 'footer.php';
?>

<?php
  include 'header.php';
  include_once 'includes/dbh.inc.php';
  if(isset($_GET['id']))
  {
    $conn = dbhandler();
    $eventID = $_GET['id'];
    $sql = "SELECT * FROM events WHERE eventID = '$eventID';";
    $result = $conn->query($sql);
    $row = $row = $result->fetch_assoc();
    $eventName = $row['eventName'];
    $eventPicturePath = $row['picturePath'];
    $eventCatogary = $row['eventCatogary'];
    $eventDetails = $row['eventDetails'];
  }


?>


<main>
  <section class="event-picture">
    <div class="wrapper">
      <h2><?php echo $eventName;?></h2>
      <img class="eventcover" src="<?php echo $eventPicturePath;?>" alt="eventpicture">
      <article>
        <h3><?php echo $eventName;?></h3>
        <div>
          <p>
            <?php echo $eventDetails;?>
          </p>
        </div>
      </article>
    </div>

  </section>
</main>




<?php
  include 'footer.php';
?>

<?php
  include 'header.php';
?>

<main>
  <section class="form-banner">
  <div class="addevent-form" style="height:560px;">
    <h1>Input Details</h1>
    <?php
/*    if(isset($_GET['event'])){
      if($_GET['event'] == "emptyfields") {
        echo '<p class="error">Fill all fields</p>';
      }
      elseif ($_GET['event'] == "sizelarge") {
        echo '<p class="error">Picture size too large</p>';
      }
      elseif ($_GET['event'] == "uploaderror") {
        echo '<p class="error">Invalid Email</p>';
      }
      elseif ($_GET['event'] == "wrongfileext") {
        echo '<p class="error">Invalid Username</p>';
      }
    }
*/
    ?>
    <form action="includes/registerprofessional.inc.php" method="post" >
      <div class="txtb">
        <label>Your Full Name :</label>
        <input type="text" name="fullname" value="" placeholder="Enter Your Name">
      </div>
      <div class="txtb">
        <label>location:</label><select name="location">
          <option>Karachi</option>
          <option>Lahore</option>
          <option>Peshawar</option>
          <option>Quetta</option>
        </select>
      </div>
      <div class="txtb">
        <label>Profession:</label><select name="profession">
          <option>CameraMan</option>
          <option>Caterer</option>
          <option>Magician</option>
        </select>
      </div>
      <div class="txtb">
        <label>Phone Number :</label>
        <input type="text" name="phonenumber" placeholder="Enter Your Phone Number">
      </div>
      <div class="txtb">
        <label>About You :</label>
        <textarea name="aboutyou" style="height:60px;"></textarea>
      </div>
      <button class="btn" type="submit" name="submit-profession">SUBMIT</button>
    </form>
  </div>
  </section>


</main>
<?php
  include 'footer.php';
?>

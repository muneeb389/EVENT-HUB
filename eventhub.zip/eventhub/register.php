<?php
    include 'header.php';
?>

  <main>
    <div class="register-banner">
      <div class="register-box">
        <img src="images/avatar.jpg" class="avatar">
          <h1 class="register-head">Register</h1>
          <?php
            if(isset($_GET['signup'])){
              if($_GET['signup'] == "emptyfields") {
                echo '<p class="error">Fill all fields</p>';
              }
              elseif ($_GET['signup'] == "invalidusernameemail") {
                echo '<p class="error">Invalid Username and Email</p>';
              }
              elseif ($_GET['signup'] == "invalidemail") {
                echo '<p class="error">Invalid Email</p>';
              }
              elseif ($_GET['signup'] == "invalidusername") {
                echo '<p class="error">Invalid Username</p>';
              }
              elseif ($_GET['signup'] == "passwordcheck") {
                echo '<p class="error">Passwords do not match</p>';
              }
              elseif ($_GET['signup'] == "usertaken") {
                echo '<p class="error">Username taken</p>';
              }
              elseif ($_GET['signup'] == "success") {
                echo '<p class="success">Account Created</p>';
              }
            }

          ?>
          <form action="includes/signup.inc.php" method="POST">
            <p class="in">Username</p>
            <input type="text" name="username" placeholder="enter username">
            <p class="in">Email</p>
            <input type="email" name="email" placeholder="enter email">
            <p class="in">Password</p>
            <input type="password" name="password" placeholder="enter password">
            <p class="in">Confirm Password</p>
            <input type="password" name="cpassword" placeholder="confirm password">
            <button class="signup" type="submit" name="submit-signup">SIGNUP</button>
          </form>
      </div>
    </div>
  </main>




<?php
    include 'footer.php';
?>

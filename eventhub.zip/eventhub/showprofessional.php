<?php
  include 'header.php';
  include_once 'includes/dbh.inc.php';

?>

<main>
  <div class="outer">
    <div class="wrapper">
      <div class="cases-links">
      <div class="searchbar">
        <form class="searchevents" action="showprofessional.php" method="post">
          <span class="searchbox-butt">
            <button class="event-btn" type="submit" name="submit-showproff">Search</button>
          </span>
          <span class="searchbox">
            <select name="location">
              <option value="" disabled selected>Location</option>
              <option>Karachi</option>
              <option>Lahore</option>
              <option>Peshawar</option>
              <option>Quetta</option>
            </select>
          </span>
          <span class="searchbox">
            <select name="profession">
              <option value="" disabled selected>Profession</option>
              <option>CameraMan</option>
              <option>Caterer</option>
              <option>Magician</option>
            </select>
          </span>
        </form>
      </div>
      <h2>Professionals</h2>
      <div class="events-toprow">
        <p class="proff-head" style="display: inline-block; margin-top: 10px; padding-right: 367px; padding-left:10px;">NAME</p>
        <p class="proff-head" style="display: inline-block; margin-top: 10px; padding-right: 367px;">LOCATION</p>
        <p class="proff-head-last" style="display: inline-block; margin-top: 10px;">PROFESSION</p>
      </div>
        <div class="links-div">
          <ul>
            <?php
            if(isset($_POST['submit-showproff']))
            {
              $conn = dbhandler();
              if(empty($_POST['location']) && empty($_POST['profession']) ){           //NONE SET(SHOW ALL) (1)
                $sql = "SELECT * FROM employee e ,users u ,location l ,profession p  WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.professionID = p.professionID ;";
              }
              else if(!empty($_POST['location']) && empty($_POST['profession']) ){           //LOCATION SET (2)
                $location = $_POST['location'];
                $sql = "SELECT * FROM employee e ,users u ,location l ,profession p  WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.professionID = p.professionID AND
                l.locationName = '$location' ;";
              }
              else if(empty($_POST['location']) && !empty($_POST['profession']) ){           //PROFESSION SET (1)
                $profession = $_POST['profession'];
                $sql = "SELECT * FROM employee e ,users u ,location l ,profession p  WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.professionID = p.professionID AND
                p.professionName = '$profession' ;";
              }
              else if(!empty($_POST['location']) && !empty($_POST['profession']) ){           //ALL SET (1)
                $profession = $_POST['profession'];
                $location = $_POST['location'];
                $sql = "SELECT * FROM employee e ,users u ,location l ,profession p  WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.professionID = p.professionID AND
                l.locationName = '$location' AND
                p.professionName = '$profession' ;";
              }
              $result = $conn->query($sql);
              while($row = $result->fetch_assoc())
              {?>
                  <li>
                    <p style="display:inline-block; width:430px; text-align: left;"><?php echo $row['fullName'] ?></p>
                    <p style="display:inline-block; width:440px; text-align: left;"><?php echo $row['locationName'] ?></p>
                    <p style="display:inline-block; width:30px; text-align: left;"><?php echo $row['professionName'] ?></p
                  </li>
              <?php
              }
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</main>


<?php
  include 'footer.php';
?>

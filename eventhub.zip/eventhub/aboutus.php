<?php
include 'header.php';
?>


<main>
  <section class="team">

    <div class="wrapper">
      <h1>OUR TEAM</h1>
      <div class="row">
        <div class="col-md-3" >
          <div class="img-box" style="width:200px;">
            <img class="profile-img" src="images/db1.jpg">
            <ul <ul style="padding-bottom:10px;">
              <a href="#"><li style="display: inline-block; padding-top:10px; width:32%; text-align: center;"><i class="fa fa-facebook"></i></li></a>
              <a href="#"><li style="display: inline-block; padding-top:10px; width:32%; text-align: center;"><i class="fa fa-instagram"></i></li></a>
              <a href="#"><li style="display: inline-block; padding-top:10px; width:32%; text-align: center;"><i class="fa fa-linkedin"></i></li></a>
            </ul>
          </div>
          <h2 style="width:200px; text-align:center; line-height: 22px; font-family: 'Architects Daughter', cursive; font-weight:1000;">SHAHZAIB BHUTTO</h2>
          <h3 style="width:200px; text-align:center; line-height: 22px; font-family: 'Architects Daughter', cursive; font-weight:500;">18k-0272</h3>
          <h4 style="width:200px; text-align:center; line-height: 22px; font-family: 'Architects Daughter', cursive; font-weight:100;">k180272@nu.edu.pk</h4>
        </div>
        <div class="col-md-3" >
          <div class="img-box" style="width:200px; ">
            <img class="profile-img" src="images/db2.jpeg">
            <ul style="padding-bottom:10px;">
              <a href="#"><li style="display: inline-block; padding-top:10px; width:32%; text-align: center;"><i class="fa fa-facebook"></i></li></a>
              <a href="#"><li style="display: inline-block; padding-top:10px; width:32%; text-align: center;"><i class="fa fa-instagram"></i></li></a>
              <a href="#"><li style="display: inline-block; padding-top:10px; width:32%; text-align: center;"><i class="fa fa-linkedin"></i></li></a>
            </ul>
          </div>
          <h2 style="width:200px; text-align:center; line-height: 22px; font-family: 'Architects Daughter', cursive;">MUNEEB ASIF</h2>
          <h3 style="width:200px; text-align:center; line-height: 22px; font-family: 'Architects Daughter', cursive; font-weight:500;">18k-1163</h3>
          <h4 style="width:200px; text-align:center; line-height: 22px; font-family: 'Architects Daughter', cursive; font-weight:500;">k181163@nu.edu.pk</h4>
        </div>
        <div class="col-md-3" >
          <div class="img-box" style="width:200px;">
            <img class="profile-img" src="images/dp3.jfif">
            <ul style="padding-bottom:10px;">
              <a href="#"><li style="display: inline-block; padding-top:10px; width:32%; text-align: center;"><i class="fa fa-facebook"></i></li></a>
              <a href="#"><li style="display: inline-block; padding-top:10px; width:32%; text-align: center;"><i class="fa fa-instagram"></i></li></a>
              <a href="#"><li style="display: inline-block; padding-top:10px; width:32%; text-align: center;"><i class="fa fa-linkedin"></i></li></a>
            </ul>
          </div>
          <h2 style="width:200px; text-align:center; line-height: 22px; font-family: 'Architects Daughter', cursive;">HASSAN ALA</h2>
          <h3 style="width:200px; text-align:center; line-height: 22px; font-family: 'Architects Daughter', cursive; font-weight:500;">18k-0173</h3>
          <h4 style="width:200px; text-align:center; line-height: 22px; font-family: 'Architects Daughter', cursive; font-weight:500;">k180173@nu.edu.pk</h4>
        </div>
      </div>
    </div>
  </section>
</main>


<?php
  include 'footer.php';
?>

<?php
    include 'header.php';
    if(isset($_SESSION['userid'])){
      header("Location: index.php");
    }
?>

<main>
  <div class="login-banner">
    <div class="login-box">
      <img src="images/avatar.jpg" class="avatar">
        <h1 class="login-head">Login here</h1>
        <form action="includes/login.inc.php" method="POST">
          <?php
            if(isset($_GET['login'])){
              if($_GET['login'] == "emptyfields") {
                echo '<p class="error">Fill all fields</p>';
              }
              elseif ($_GET['login'] == "wrongpwd") {
                echo '<p class="error">Wrong Password</p>';
              }
              elseif ($_GET['login'] == "nouser") {
                echo '<p class="error">No User Exists With This Name</p>';
              }
            }
          ?>
          <p>Username</p>
          <input type="text" name="username" placeholder="enter username">
          <p>Password</p>
          <input type="password" name="password" placeholder="enter password">
          <button type="submit" name="submit-login">Login</button>
          <a href="#">Forget password</a>
        </form>
    </div>
  </div>
</main>

<?php
    include 'footer.php';
?>

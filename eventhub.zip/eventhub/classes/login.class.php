<?php

class Login{
  //properties
  protected $username;
  protected $password;
  //methods
  public function setuserdata($username , $password)
  {
    $this->username = $username;
    $this->password = $password;
  }
  public function showall()
  {
    echo $this->username;
    echo $this->password;
  }
  public function checkloginvalidation()
  {
    $conn = dbhandler();
    if(empty($this->username) || empty($this->password))
    {
      header("Location: ../login.php?login=emptyfields&username=".$this->username);
      exit();
    }
    else
    {
      $sql = "SELECT * FROM users WHERE username=? OR email=?;";
      $stmt = $conn->stmt_init();
      if(!$stmt->prepare($sql))
      {
        header("Location: ../login.php?login=sqlerror");
        exit();
      }
      else
      {
        $stmt->bind_param("ss", $this->username , $this->username);
        $stmt->execute();
        $result = $stmt->get_result();
        if($row = $result -> fetch_assoc())
        {
          $pwdcheck = password_verify($this->password , $row['pwd']);
          if($pwdcheck == false)
          {
            header("Location: ../login.php?login=wrongpwd");
            exit();
          }
          elseif($pwdcheck == true)
          {
            session_start();
            $_SESSION['userid'] = $row['user_id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['type'] = $row['type'];
            header("Location: ../index.php?login=success");
            exit();
          }
        }
        else
        {
          header("Location: ../login.php?login=nouser");
          exit();
        }
      }
    }
  }
}

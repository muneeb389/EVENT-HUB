<?php
include_once '../includes/dbh.inc.php';

class Registerprofessional{
  //properties
  protected $fullName;
  protected $location;
  protected $profession;
  protected $number;
  protected $aboutYou;
  //methods
  public function setdetais($fullName,$location,$profession,$number,$aboutYou)
  {
    $this->fullName = $fullName;
    $this->location = $location;
    $this->profession = $profession;
    $this->number = $number;
    $this->aboutYou = $aboutYou;
  }
  public function showall()
  {
    echo $this->fullName;
  }
  public function checkvalidation()
  {
    if (empty($this->fullName) || empty($this->location) || empty($this->profession) || empty($this->number) || empty($this->aboutYou))
    {
      header("Location: ../registerprofessional.php?prof=emptyfields");
    }
    else {
      $this->adddata();
    }
  }
  public function adddata()
  {
    $connl = dbhandler();
    $connp = dbhandler();
    $conn = dbhandler();
    session_start();
    $locsql = "SELECT * FROM location WHERE locationName = '$this->location'";
    $profsql = "SELECT * FROM profession WHERE professionName = '$this->profession'";
    $resultl = $connl->query($locsql);
    $resultp= $connp->query($profsql);
    $rowl = $resultl->fetch_assoc();
    $rowp = $resultp->fetch_assoc();
    $locationID = $rowl['locationID'];
    $professionID = $rowp['professionID'];
    $userID = $_SESSION['userid'];
    $sql = "INSERT INTO employee (user_id, fullName, locationID , professionID , phoneNumber , aboutYou )
    VALUES ('$userID', '$this->fullName', '$locationID' , '$professionID' , '$this->number' ,  '$this->aboutYou')";
    if (!$conn->query($sql) === TRUE) {
      header("Location: ../registerprofessional.php?sqlerror");
    }
    else {
      header("Location: ../registerprofessional.php?upload=success");
    }
  }
}

<?php
include_once '../includes/dbh.inc.php';


class Signup{
  //properties
  protected $username;
  protected $email;
  protected $password;
  protected $cpassword;
  protected $type = '1';
  //methods
  public function message()
  {
    echo "Hello";
  }
  public function setuserdata($username,$email,$password,$cpassword)
  {
    $this->username = $username;
    $this->email = $email;
    $this->password = $password;
    $this->cpassword = $cpassword;
  }
  public function showall()
  {
    echo $this->username;
    echo $this->password;

  }
  public function checkvalidation()
  {
    $conn = dbhandler();
    if(empty($this->username) || empty($this->email) || empty($this->password) || empty($this->cpassword))
    {
      header("Location: ../register.php?signup=emptyfields&username=".$this->username."&email=".$this->email);
      exit();
    }
    elseif(!filter_var($this->email , FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/" , $this->username))
    {
      header("Location: ../register.php?signup=invalidusernameemail");
      exit();
    }
    elseif(!filter_var($this->email,FILTER_VALIDATE_EMAIL))
    {
      header("Location: ../register.php?signup=invalidemail&username=".$this->username);
      exit();
    }
    elseif(!preg_match("/^[a-zA-Z0-9]*$/",$this->username))
    {
      header("Location: ../register.php?signup=invalidusername&email=".$this->email);
      exit();
    }
    elseif($this->password !== $this->cpassword)
    {
      header("Location: ../register.php?signup=passwordcheck&username=".$this->username."&email=".$this->email);
      exit();
    }
    else
    {
      $sql = "SELECT username FROM users WHERE username=?";
      $stmt = $conn->stmt_init();
      if(!$stmt->prepare($sql))
      {
        header("Location: ../register.php?signup=sqlerror");
        exit();
      }
      else
      {
        $stmt->bind_param("s", $this->username);
        $stmt->execute();
        $stmt->store_result();
        $resultcheck = $stmt->num_rows;
        if($resultcheck > 0)
        {
          header("Location: ../register.php?signup=usertaken&email=".$this->email);
          exit();
        }
        else
        {
          $sql = "INSERT INTO users (username , email , pwd , type) VALUES (? ,? , ? , ?)";
          $stmt = $conn->stmt_init();
          if(!$stmt->prepare($sql))
          {
            header("Location: ../register.php?signup=sqlerror");
            exit();
          }
          else
          {
            $hashedpwd = password_hash($this->password , PASSWORD_DEFAULT);
            $stmt->bind_param("ssss", $this->username , $this->email , $hashedpwd , $this->type);
            $stmt->execute();
            header("Location: ../register.php?signup=success");
            exit();
          }
        }
      }
    }
    $stmt->close();
    $conn->close();
  }
}

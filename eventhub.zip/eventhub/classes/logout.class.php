<?php

class Logout{
  //properties

  //methods
  public function clearAllSessions()
  {
    session_start();
    session_unset();
    session_destroy();
  }
}

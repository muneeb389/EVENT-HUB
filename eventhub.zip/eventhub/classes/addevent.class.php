
<?php
class Addevent{
  //properties
  protected $eventname;
  protected $location;
  protected $catogary;
  protected $number;
  protected $file;
  protected $eventDate;
  protected $eventdetails;
  protected $isApprove = '0';
  //methods
  public function seteventdetais($eventname,$location,$catogary,$number,$file,$eventDate,$eventdetails)
  {
    $this->eventname = $eventname;
    $this->location = $location;
    $this->catogary = $catogary;
    $this->number = $number;
    $this->file = $file;
    $this->eventDate = $eventDate;
    $this->eventdetails = $eventdetails;
  }
  public function showall()
  {
    $file = $this->file;
    print_r($file);
  }
  public function checkeventvalidation()
  {
    if(empty($this->eventname) || empty($this->location) || empty($this->catogary) || empty($this->number) || empty($this->file) || empty($this->eventdetails) || empty($this->eventDate))
    {
      header("Location: ../addevent.php?event=emptyfields&eventname=".$this->eventname."&location=".$this->location."&catogary=".$this->catogary."&number=".$this->number."&eventdetails=".$this->eventdetails);
      exit();
    }
    else {
      $file = $this->file;
      $fileName = $file['name'];
      $fileTmpName = $file['tmp_name'];
      $fileSize = $file['size'];
      $fileError = $file['error'];
      $fileType = $file['type'];
      $fileExt = explode('.',$fileName);
      $fileActualExt = strtolower(end($fileExt));
      $allowed = array('jpg','jpeg','png');
      if(in_array($fileActualExt , $allowed)){
        if ($fileError === 0) {
          if ($fileSize < 1000000) {
            $fileNameNew = uniqid('' , true).".".$fileActualExt;
            $fileDestination = '../uploads/'.$fileNameNew;
            $fileLocation = 'uploads/'.$fileNameNew;
            $this->adddata($fileTmpName , $fileDestination , $fileLocation);
            //header("Location: ../addevent.php?upload=success");
          }
          else {
            header("Location: ../addevent.php?event=sizelarge");
          }
        }else {
          header("Location: ../addevent.php?event=uploaderror");
        }
      }
      else {
        header("Location: ../addevent.php?event=wrongfileext");
      }
    }
  }
  public function adddata($fileTmpName , $fileDestination , $fileLocation)
  {
    $connl = dbhandler();
    $connc = dbhandler();
    $conn = dbhandler();
    session_start();
    move_uploaded_file($fileTmpName , $fileDestination);
    $locsql = "SELECT * FROM location WHERE locationName = '$this->location'";
    $catsql = "SELECT * FROM catogary WHERE catogaryName = '$this->catogary'";
    $resultl = $connl->query($locsql);
    $resultc= $connc->query($catsql);
    $rowl = $resultl->fetch_assoc();
    $rowc = $resultc->fetch_assoc();
    $locationID = $rowl['locationID'];
    $catogaryID = $rowc['catogaryID'];
    $userID = $_SESSION['userid'];
    $sql = "INSERT INTO events (user_id, eventName, locationID , catogaryID , phoneNumber , picturePath , eventDate , eventDetails , isApprove)
    VALUES ('$userID', '$this->eventname', '$locationID' , '$catogaryID' , '$this->number' , '$fileLocation' ,'$this->eventDate', '$this->eventdetails' , '$this->isApprove')";
    if (!$conn->query($sql) === TRUE) {
      header("Location: ../addevent.php?sqlerror");
    }
    else {
      header("Location: ../addevent.php?upload=success");
    }
    //header("Location: ../addevent.php?upload=success");
  }
}


    <footer>
      <ul class="footer-links-main">
        <li><a href="index.php">HOME</a></li>
        <li><a href="events.php">EVENTS</a></li>
        <li><a href="aboutus.php">ABOUT US</a></li>

      </ul>
  <!--    <ul class="footer-links-cases">
        <li><p>Latest EVENTS</p></li>
        <li><a href="#">MALING STATION - WEB DEVELOPMENT</a></li>
        <li><a href="#">EXCELLENT - WEB DEVELOPMENT</a></li>
        <li><a href="#">EVENTS - YOUTUBE CHANNEL</a></li>
        <li><a href="#">ARENA - VIDEO PRODUCTION</a></li>
      </ul>-->
      <div class="footer-sm">
        <a href="#">
          <img class="logo" src="images/youtube.png" alt="youtube logo">
        </a>
        <a href="#">
          <img class="logo" src="images/twitter.png" alt="youtube logo">
        </a>
        <a href="#">
          <img class="logo" src="images/facebook.png" alt="youtube logo">
        </a>
      </div>
    </footer>
  </body>
</html>

<?php
  include 'header.php';
  include_once 'includes/dbh.inc.php';
?>
<main>
  <div class="wrapper">
    <div class="appevent-list">
      <h2>APPROVE EVENTS</h2>
      <div class="appevent-toprow">
        <p class="appevent-head">USER NAME</p>
        <p class="appevent-head">EVENTNAME</p>
        <p class="appevent-head-last">LOCATION</p>

      </div>
      <div class="user-links">
        <ul>
        <?php
        $conn = dbhandler();
        $sql = "SELECT * FROM events e ,users u , location l , catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID";
                $result = $conn->query($sql);

      //if ($result->num_rows > 0)
      //{
        while($row = $result->fetch_assoc())
        {
          if($row['isApprove']==0) {?>
          <li>
            <p style="display:inline-block; width:420px; text-align: left;"><?php echo $row['username'] ?></p>
            <p style="display:inline-block; width:400px; text-align: left;"><?php echo $row['eventName'] ?></p>
            <p style="display:inline-block; width:370px; text-align: left;"><?php echo $row['locationName'] ?></p>
            <p style="display:inline-block; width:250px; text-align: left;">
              <a href="includes/add.inc.php?id=<?php echo $row['eventID'] ?>" style="display:inline-block;"><button type="approved" name="approved" style="background-color:red; border-color:blue; color:white">APPROVE</button></a>
            </p>
            <p style="display:inline-block; width:250px; text-align: left;">
              <a href="includes/drop.inc.php?id=<?php echo $row['eventID'] ?>" style="display:inline-block;"><button  type="declined"  name="declined" style="background-color:red; border-color:blue; color:white">DECLINE </button></a>
            </p>

          </li>
          <?php

  }}
   ?>
    </ul>
   </div>
  </div>
 </div>
</main>

<?php
  include 'footer.php';
?>

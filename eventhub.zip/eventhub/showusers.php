<?php
include 'header.php';
include_once 'includes/dbh.inc.php';
?>


<main>
  <div class="wrapper">
    <div class="users-list">
      <h2>EVENTS</h2>
      <div class="users-toprow">
        <p class="users-head">USER NAME</p>
        <p class="users-head">EMAIL</p>
        <p class="users-head-last">NUMBER OF EVENTS</p>
      </div>
      <div class="user-links">
        <ul>
        <?php
        $conn = dbhandler();
        $sql = "SELECT U.username, U.email , COUNT(E.eventID) AS NumberOfEvents, U.type
                FROM users U
                LEFT JOIN events E
                ON U.user_id = E.user_id
                WHERE U.type = 1
                GROUP BY U.user_id";
                $result = $conn->query($sql);

      if ($result->num_rows > 0)
      {
        while($row = $result->fetch_assoc())
        {?>
          <li>
            <p style="display:inline-block; width:530px; text-align: left;"><?php echo $row['username'] ?></p>
            <p style="display:inline-block; width:650px; text-align: left;"><?php echo $row['email'] ?></p>
            <p style="display:inline-block; width:150px; text-align: left;"><?php echo $row['NumberOfEvents'] ?></p>
          </li>
          <?php
        }}
        else {
    echo "0 results";
  }

   ?>
    </ul>
   </div>
  </div>
 </div>
</main>


<?php
  include 'footer.php';
?>

<?php
  session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width , initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
<!--    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"> -->
    <title>None</title>
  </head>
  <body>
    <header>
      <a href="index.php" class="header-brand">events hub</a>
      <nav>
        <ul>
          <?php
          if(!isset($_SESSION['userid']))
          {
          ?>
          <li><a href="register.php">Register</a></li>
          <li><a href="login.php">Login</a></li>
          <?php
          }
          else{
            ?>
            <li><a href="includes/logout.inc.php">Logout</a></li>
          <?php
          }
          ?>
          <li><a href="aboutus.php">About Us</a></li>
        </ul>
        <?php
        if(isset($_SESSION['userid']))
        {
          //echo $_SESSION['type'];
          if($_SESSION['type'] === '0'){
            ?>
            <a href="approveevent.php" class="header-cases">Approve Events</a>
            <a href="showusers.php" class="header-cases">Show Users</a>
          <?php }
          else { ?>
            <a href="addevent.php" class="header-cases">Add Events</a>
            <a href="registerprofessional.php" class="header-cases">Register As A Professional</a>
            <a href="showprofessional.php" class="header-cases">Hire A Professional</a>
          <?php }
          } ?>
          <a href="events.php" class="header-cases">Show Events</a>


      </nav>
    </header>

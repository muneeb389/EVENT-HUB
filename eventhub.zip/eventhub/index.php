<?php
  include 'header.php';
?>

<main>
  <?php
  if(!isset($_SESSION['userid']))
  {
  ?>
  <section class="index-banner">
    <div class="vertical-center">
      <h2>THIS IS THE EVENT HUB<br></h2>
      <h1>with specialty in organizing, developing, functioning all the evrnts under one roof</h1>
    </div>
  </section>
  <div class="wrapper">
    <section class="index-links">
      <a href="events.php">
        <div class="index-boxlink-square">
          <h3>Events</h3>
        </div>
      </a>
      <a href="showprofessional.php">
        <div class="index-boxlink-rectangle">
          <h3>Hire A Professional</h3>
        </div>
      </a>
      <a href="aboutus.php">
        <div class="index-boxlink-square">
          <h3>About Us</h3>
        </div>
      </a>
    </section>
  </div>
  <div style="padding-bottom:20px;">

  </div>
  <?php
  }
  else{
    if ($_SESSION['type'] === '0') {
      ?>
      <div class="wrapper">
        <div class="user-page" style="height: 100vh; background-color: pink;">
          <h1 style="text-align:center; font-size:50px;">HELLO ADMIN</h1>
        </div>
      </div>
      <?php
    }
    else {
      ?>
      <div class="wrapper">
        <div class="user-page" style="height: 100vh; background-color: pink;">
          <h1 style="text-align:center; font-size:50px;">WELCOME <?php echo strtoupper($_SESSION['username']); ?></h1>
        </div>
      </div>
      <?php
    }
  }
  ?>
</main>

<?php
  include 'footer.php';
?>

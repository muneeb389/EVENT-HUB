<?php
include '../classes/registerprofessional.class.php';
include_once 'dbh.inc.php';

if(isset($_POST['submit-profession']))
{
  $professional = new Registerprofessional();
  $professional->setdetais($_POST['fullname'] , $_POST['location'] , $_POST['profession'] , $_POST['phonenumber'] , $_POST['aboutyou']);
  $professional->checkvalidation();
}

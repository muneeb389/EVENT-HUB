<?php
include '../classes/addevent.class.php';
include_once 'dbh.inc.php';

if(isset($_POST['submit-addevent']))
{
  $event = new Addevent();
  $event->seteventdetais($_POST['eventname'] , $_POST['location'] , $_POST['catogary'] , $_POST['phonenumber'] , $_FILES['file'] ,$_POST['eventdate'] ,$_POST['eventdetails']);
  $event->checkeventvalidation();
}

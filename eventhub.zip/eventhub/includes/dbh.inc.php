<?php

function dbhandler()
{
  $dbservername = "localhost";       //keep same
  $dbusername = "root";              //keep same
  $dbpassword = "";
  $dbname = "dani";                  //name of your dbname
  $conn = new mysqli($dbservername , $dbusername , $dbpassword , $dbname);
  if ($conn -> connect_errno)
  {
    echo "Failed to connect to MySQL: " . $conn -> connect_error;
    exit();
  }
  return $conn;
}

<?php
include_once '../classes/signup.class.php';
include_once 'dbh.inc.php';

if(isset($_POST['submit-signup']))
{
  $user = new Signup();
  $user->setuserdata($_POST['username'] , $_POST['email'] , $_POST['password'] , $_POST['cpassword'] );
  $user->checkvalidation();
}
else
{
    header("Location: ../register.php");
    exit();
}

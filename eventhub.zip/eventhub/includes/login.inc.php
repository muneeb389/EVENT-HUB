<?php
include_once '../classes/login.class.php';
include_once 'dbh.inc.php';

if(isset($_POST['submit-login']))
{
  $user = new Login();
  $user->setuserdata($_POST['username'] , $_POST['password']);
  $user->checkloginvalidation();
}
else
{
  header("Location: ../login.php");
  exit();
}

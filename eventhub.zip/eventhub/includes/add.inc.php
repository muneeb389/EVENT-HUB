<?php
  include_once 'dbh.inc.php';


  if(isset($_GET['id']))
  {
    $conn = dbhandler();
    $eventID = $_GET['id'];
    $sql = "UPDATE events SET isApprove = 1 WHERE eventID = '$eventID';";
    $result = $conn->query($sql);
  }
  header("Location: ../approveevent.php?app=done");

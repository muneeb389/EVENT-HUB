<?php

include_once '../classes/logout.class.php';

$finish = new Logout();
$finish->clearAllSessions();
header("Location: ../index.php");

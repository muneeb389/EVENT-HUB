<?php
  include 'header.php';
  include_once 'includes/dbh.inc.php';

?>

<main>
  <div class="outer">
    <div class="wrapper">
      <div class="cases-links">
      <div class="searchbar">
        <form class="searchevents" action="events.php" method="post">
          <span class="searchbox-butt">
            <button class="event-btn" type="submit" name="submit-showevent">Search</button>
          </span>
          <span class="searchbox">
            <select name="location">
              <option value="" disabled selected>Location</option>
              <option>Karachi</option>
              <option>Lahore</option>
              <option>Peshawar</option>
              <option>Quetta</option>
            </select>
          </span>
          <span class="searchbox">
            <select name="catogary">
              <option value="" disabled selected>Catogary</option>
              <option>Carnival</option>
              <option>Concert</option>
              <option>Qawali</option>
            </select>
          </span>
          <span class="searchbox">
            <input type="date" name="eventbefore" placeholder="Event Before " onchange="this.className=(this.value!=''?'has-value':'')">
          </span>
          <span class="searchbox">
            <input type="date" name="eventafter" placeholder="Event After.  " onchange="this.className=(this.value!=''?'has-value':'')">
          </span>
        </form>
      </div>
      <h2>EVENTS </h2>
      <div class="events-toprow">
        <p class="event-head">EVENT NAME</p>
        <p class="event-head">HOST NAME</p>
        <p class="event-head">EVENT LOCATION</p>
        <p class="event-head">CATOGARY</p>
        <p class="event-head-last">EVENT DATE</p>
      </div>
        <div class="links-div">
          <ul>
            <?php
            if(isset($_POST['submit-showevent']))
            {
              $conn = dbhandler();
              if(empty($_POST['location']) && empty($_POST['catogary']) && empty($_POST['eventbefore']) && empty($_POST['eventafter'])){           //NONE SET(SHOW ALL) (1)
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c  WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1';";

              }
              elseif (!empty($_POST['location']) && empty($_POST['catogary']) && empty($_POST['eventbefore']) && empty($_POST['eventafter'])) {    //ONLY LOCATION SET (2)
                $location = $_POST['location'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                l.locationName = '$location';";
              }
              elseif (empty($_POST['location']) && !empty($_POST['catogary']) && empty($_POST['eventbefore']) && empty($_POST['eventafter'])) {    //ONLY CATOGARY SET (3)
                $catogary = $_POST['catogary'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                c.catogaryName = '$catogary';";
              }
              elseif (empty($_POST['location']) && empty($_POST['catogary']) && !empty($_POST['eventbefore']) && empty($_POST['eventafter'])) {    //ONLY EVENTBEFORE SET (4)
                $eventbefore = $_POST['eventbefore'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                e.eventDate < '$eventbefore';";
              }
              elseif (empty($_POST['location']) && empty($_POST['catogary']) && empty($_POST['eventbefore']) && !empty($_POST['eventafter'])) {    //ONLY EVENTAFTER SET  (5)
                $eventafter = $_POST['eventafter'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                e.eventDate > '$eventafter';";
              }
              elseif (!empty($_POST['location']) && !empty($_POST['catogary']) && empty($_POST['eventbefore']) && empty($_POST['eventafter'])){   //LOCATION AND CATOGARY SET (6)
                $location = $_POST['location'];
                $catogary = $_POST['catogary'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                l.locationName = '$location' AND
                c.catogaryName = '$catogary';";
              }
              elseif (!empty($_POST['location']) && empty($_POST['catogary']) && !empty($_POST['eventbefore']) && empty($_POST['eventafter'])){   //LOCATION AND EVENTBEFORE SET (7)
                $location = $_POST['location'];
                $eventbefore = $_POST['eventbefore'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                l.locationName = '$location' AND
                e.eventDate < '$eventbefore';";
              }
              elseif (!empty($_POST['location']) && empty($_POST['catogary']) && empty($_POST['eventbefore']) && !empty($_POST['eventafter'])){   //LOCATION AND EVENTBAFTER SET (8)
                $location = $_POST['location'];
                $eventafter = $_POST['eventafter'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                l.locationName = '$location' AND
                e.eventDate > '$eventafter';";
              }
              elseif (empty($_POST['location']) && !empty($_POST['catogary']) && !empty($_POST['eventbefore']) && empty($_POST['eventafter'])){   //CATOGARY AND EVENTBEFORE SET (9)
                $catogary = $_POST['catogary'];
                $eventbefore = $_POST['eventbefore'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                c.catogaryName = '$catogary' AND
                e.eventDate < '$eventbefore';";
              }
              elseif (empty($_POST['location']) && !empty($_POST['catogary']) && empty($_POST['eventbefore']) && !empty($_POST['eventafter'])){   //CATOGARY AND EVENTAFTER SET (10)
                $catogary = $_POST['catogary'];
                $eventafter = $_POST['eventafter'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                c.catogaryName = '$catogary' AND
                e.eventDate > '$eventafter';";
              }
              elseif (empty($_POST['location']) && empty($_POST['catogary']) && !empty($_POST['eventbefore']) && !empty($_POST['eventafter'])){   //EVEBTBEFORE AND EVENTAFTER SET (11)
                $eventafter = $_POST['eventafter'];
                $eventbefore = $_POST['eventbefore'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                e.eventDate < '$eventbefore' AND
                e.eventDate > '$eventafter';";
              }
              elseif (!empty($_POST['location']) && !empty($_POST['catogary']) && !empty($_POST['eventbefore']) && empty($_POST['eventafter'])){   //LOCATION AND CATOGARY (12)
                $location = $_POST['location'];                                                                                                    //EVEBTBEFORE SET
                $catogary = $_POST['catogary'];
                $eventbefore = $_POST['eventbefore'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                c.catogaryName = '$catogary' AND
                l.locationName = '$location' AND
                e.eventDate < '$eventbefore';";
              }
              elseif (!empty($_POST['location']) && empty($_POST['catogary']) && !empty($_POST['eventbefore']) && !empty($_POST['eventafter'])){   //EVEBTBEFORE AND EVENTAFTER SET (13)
                $location = $_POST['location'];                                                                                                     //LOCATION SET
                $eventbefore = $_POST['eventbefore'];
                $eventafter = $_POST['eventafter'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                l.locationName = '$location' AND
                e.eventDate < '$eventbefore' AND
                e.eventDate > '$eventafter';";
              }
              elseif (!empty($_POST['location']) && !empty($_POST['catogary']) && empty($_POST['eventbefore']) && !empty($_POST['eventafter'])){   //EVEBTBEFORE AND EVENTAFTER SET (14)
                $location = $_POST['location'];                                                                                                     //LOCATION SET
                $catogary = $_POST['catogary'];
                $eventafter = $_POST['eventafter'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                l.locationName = '$location' AND
                e.eventCatogary = '$catogary' AND
                e.eventDate > '$eventafter';";
              }
              elseif (empty($_POST['location']) && !empty($_POST['catogary']) && !empty($_POST['eventbefore']) && !empty($_POST['eventafter'])){   //EVEBTBEFORE AND EVENTAFTER SET (15)
                $eventbefore = $_POST['eventbefore'];                                                                                                     //CATOGARY SET
                $catogary = $_POST['catogary'];
                $eventafter = $_POST['eventafter'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                e.eventDate < '$eventbefore' AND
                c.catogaryName = '$catogary' AND
                e.eventDate > '$eventafter';";
              }
              elseif (!empty($_POST['location']) && !empty($_POST['catogary']) && !empty($_POST['eventbefore']) && !empty($_POST['eventafter'])){   //ALL SET(16)
                $location = $_POST['location'];
                $eventbefore = $_POST['eventbefore'];
                $catogary = $_POST['catogary'];
                $eventafter = $_POST['eventafter'];
                $sql = "SELECT * FROM events e ,users u ,location l ,catogary c WHERE
                e.user_id = u.user_id AND
                e.locationID = l.locationID AND
                e.catogaryID = c.catogaryID AND
                e.isApprove = '1' AND
                l.locationName = '$location' AND
                e.eventDate < '$eventbefore' AND
                c.catogaryName = '$catogary' AND
                e.eventDate > '$eventafter';";
              }

              $result = $conn->query($sql);
              while($row = $result->fetch_assoc())
              {?>
                <a href="eventdetails.php?id=<?php echo $row['eventID'] ?>">
                  <li>
                    <p style="display:inline-block; width:220px; text-align: left;"><?php echo $row['eventName'] ?></p>
                    <p style="display:inline-block; width:220px; text-align: left;"><?php echo $row['username'] ?></p>
                    <p style="display:inline-block; width:220px; text-align: left;"><?php echo $row['locationName'] ?></p>
                    <p style="display:inline-block; width:200px; text-align: left;"><?php echo $row['catogaryName'] ?></p
                    <p style="display:inline-block;"><?php echo $row['eventDate'] ?></p>
                  </li>
                </a>
              <?php
              }
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</main>


<?php
  include 'footer.php';
?>
